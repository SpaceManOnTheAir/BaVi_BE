package com.example.demo.entity;

public enum Status {
PAID,
UNPAID
}
